# SPDX-License-Identifier: BSD-3-Clause


class LsrNetworkNmError(Exception):
    pass
